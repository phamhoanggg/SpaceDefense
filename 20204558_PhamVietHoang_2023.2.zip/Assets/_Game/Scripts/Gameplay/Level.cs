using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Level : MonoBehaviour
{
    public List<ResourcesType> resAvailableList;
    public List<Enemy> enemyList;
    public string planetName;
    public int LevelIndex;
}
