using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mine : MonoBehaviour, IDrillable
{
    public ResourcesType resType;
    public PropsType propType;
    public PoolType propPoolType;
}
