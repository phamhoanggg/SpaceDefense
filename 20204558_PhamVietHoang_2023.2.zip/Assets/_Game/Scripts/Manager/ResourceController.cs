using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResourceController : SingletonMB<ResourceController>
{
    public List<GameObject> resourceList;
    public List<GameObject> obstacleList;
}
