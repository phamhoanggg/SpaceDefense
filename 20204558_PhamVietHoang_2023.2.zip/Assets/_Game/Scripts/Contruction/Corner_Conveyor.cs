using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Corner_Conveyor : Conveyor
{
    
}
